level = []
with open('levels/level1.txt', 'r') as big_file:
    level = big_file.read().split('\n')

print(level)
