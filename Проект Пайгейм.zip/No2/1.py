import pygame
import os
pygame.init()
sc = pygame.display.set_mode((500, 500))
sc.fill((0, 0, 0))


def load_image(name, colorkey=None):

    image = pygame.image.load(name).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    image.save()


load_image('soilder/d.png', (255, 255, 255))