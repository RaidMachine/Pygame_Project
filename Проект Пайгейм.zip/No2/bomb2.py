import pygame, os, random

pygame.init()
sc = pygame.display.set_mode((1280, 720))
sc.fill((0, 0, 0))


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Bomb(pygame.sprite.Sprite):

    def __init__(self, group, image, image_boom):
        super().__init__(group)
        self.image = image
        self.image_boom = image_boom
        self.rect = self.image.get_rect()

        while True:
            self.rect.topleft = (random.randrange(0, 1250), random.randrange(0, 690))
            if len(pygame.sprite.spritecollide(self, traps, False)) == 1:
                break

    def update(self, *args):
        if args and args[0].type == pygame.MOUSEBUTTONDOWN and \
                self.rect.collidepoint(args[0].pos):
            self.image = self.image_boom

traps = pygame.sprite.Group()

def set_pos():
    global all_sprites
    for i in range(random.randint(10, 100)):
        Bomb(traps, load_image("mine.png", (255, 255, 255)),
             load_image("mine.png", (255, 255, 255)))

def arming():
    set_pos()
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                all_sprites.update(event)
        sc.fill(pygame.Color(0, 0, 0))
        traps.draw(sc)
        pygame.display.flip()
    pygame.quit()

arming()
print(all_sprites)
